# NutriTrack - Intelligent Calorie & Nutrient Tracker 🌍🍽️

NutriTrack helps users track calories, macros, meals, and Nigerian + global dishes with AI-powered logging, charts, and gamified feedback.

## 🔥 Features

- AI meal analysis with Gemini Vision + Gemini Text
- Full African + global food database
- Daily calorie rings, streaks, badges, weekly charts
- Custom daily goals, templates, reminders
- PWA: offline, installable, responsive
- Export as PDF/CSV, synced via Firebase

## 📦 Folder Structure

```
index.html            # Main app UI & logic
manifest.json         # PWA config
service-worker.js     # Offline support
icons/                # App icons (192x192, 512x512)
```

## 🚀 Firebase Hosting Deployment

### 1. Install Firebase CLI
```bash
npm install -g firebase-tools
```

### 2. Login & Init
```bash
firebase login
firebase init hosting
# public directory: nutritrack
# SPA: Yes
```

### 3. Deploy
```bash
firebase deploy
```

## 📲 Run Locally
Use a static server:
```bash
npx serve .
```

## 💡 Future Ideas

- Voice logging with Web Speech API
- Image recognition for portion estimation
- Regional community features